package Parser;

import java.lang.*;
import java.util.*;

 class student 
{
	public  String name;
	public  String gender;
	public  String sr;
	public  String deptmail;
	public  String email;
	public  String uid;
	public  String degree;
	public  String dept;
	public  String state;
	public  String cgpa;
	public  int psne;
	public  int msne;
	public  int minmax;
	public  int saddlept;
	public  int asks;
	public  int days;
	public  int answers;
	public  int posts;
		 
	 
student(String name,
  String gender,
  String sr,
  String deptmail,
  String email,
  String uid,
  String degree,
  String dept,
  String state,
  String cgpa,
  int psne,
  int msne,
  int minmax,
  int saddlept,
  int asks,
  int days,
  int answers,
  int posts)
{
	 this.name=name;
	 this.gender=gender;
	 this.sr=sr;
	 this.deptmail=deptmail;
	 this.email=email;
	 this.uid=uid;
	 this.degree=degree;
	 this.dept=dept;
	 this.state=state;
	 this.cgpa=cgpa;
	 this.psne=psne;
	 this. msne=msne;
	 this. minmax=msne;
	 this.saddlept=saddlept;
	 this.asks=asks;
	 this.days=days;
	 this.answers=answers;
	 this.posts=posts;
		 	
}

}